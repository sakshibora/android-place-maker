package com.example.saksh.myapplication;



/*
 * @author Gurjas Singh
 * Brillica Services, Dehradun
 * 7/May/2018*/

/*
 * Creating Student class to store the data into
 * ArrayList*/
public class Student {

    /*
     * Creating different class variable that would
     * get the value of each and every object*/

    String email;
    int password;


    /*
     * Creating a constructor in which we will pass the respective data i.e.
     * studentName, studentCollege, studentPhoneNumber, studentAddress*/

    public Student(String email,  int password
                   ) {
        this.email = email;
        this.password = password;

    }

    /*
     * Creating a getter setter method.*/

    public String getemail() {
        return email;
    }

    public int getpassword() {
        return password;
    }



    public void setemail(String email) {
        this.email = email;
    }

    public void setpassword(int password
    ) {
        this.password = password;
    }


}

