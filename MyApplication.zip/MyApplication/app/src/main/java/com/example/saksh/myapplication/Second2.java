package com.example.saksh.myapplication;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.brillicaservices.gurjas.studentmanagementsystem.R;

import static com.example.saksh.myapplication.R.id.text15;

public class Second2 extends AppCompatActivity {


    TextView fname,lname,pno,email_id,passw,confirmpassw;

    Button regis;
    EditText fn,ln,pn,ei;
    int pa = findViewById(R.id.text15),cp = findViewById(R.id.text16);
    @SuppressLint("CutPasteId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second2);

        fname = findViewById(R.id.text30);
        lname = findViewById(R.id.text31);
        pno = findViewById(R.id.text32);
        email_id = findViewById(R.id.text33);
        passw = findViewById(R.id.text34);
        confirmpassw = findViewById(R.id.text35);
        regis = findViewById(R.id.text17);
        fn = findViewById(R.id.text11);
         ln = findViewById(R.id.text12);
        pn = findViewById(R.id.text13);
        ei = findViewById(R.id.text14);



        newuser.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                /* getting input from customer like customerName, capacity and quantity of coffee*/
                String name = email.getText().toString();
                int pass = Integer.parseInt(password.getText().toString());


                Toast.makeText(getApplicationContext(), " data saved successfully", Toast.LENGTH_LONG).show();


            }
}
